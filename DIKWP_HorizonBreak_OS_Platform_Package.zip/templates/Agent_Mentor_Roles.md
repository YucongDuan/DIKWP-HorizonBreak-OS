# Mentor Council Role Template

- Role name:
- Primary DIKWP layer:
- Allowed moves:
- Forbidden moves:
- Evidence requirement:
- Sample challenge:

## Default roles
Formalist, Engineer, Historian, Skeptic, Ethicist, Artist, Teacher, Field Observer, Opposing School, Future Self.
