# DIKWP Thought Packet

## D - Data

## I - Information / Distinctions

## K - Knowledge / Claims

## W - Wisdom / Tradeoffs

## P - Purpose / Goals

## Residuals

## Kill Conditions
