# Reality Test Ticket

- Hypothesis:
- Minimal reversible test:
- Required evidence:
- Success threshold:
- Kill condition:
- Time window:
- Action grade:
- Recovery path:
