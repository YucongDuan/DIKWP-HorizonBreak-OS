# Source Ledger

This package uses the following sources as theory and design references. ResearchGate technical reports are treated as preprint/technical inspiration rather than conclusive peer-reviewed validation.

1. Yucong Duan et al., The DIKWP Collapse Theory: A Comprehensive Analysis. ResearchGate, 2025. https://www.researchgate.net/publication/389348474_The_DIKWP_Collapse_Theory_A_Comprehensive_Analysis
2. Yucong Duan, Shuaishuai Huang, Shiming Gong, DIKWP Collapse: Modeling Report on Possibility, Criterion, Impact and Governance Based on DIKWP×DIKWP Interaction Paths. ResearchGate, 2026. https://www.researchgate.net/publication/404862604_DIKWP_Collapse_Modeling_Report_on_Possibility_Criterion_Impact_and_Governance_Based_on_DIKWPDIKWP_Interaction_Paths
3. Yucong Duan, Shuaishuai Huang, Shiming Gong, From Planck Constant to Landauer's Principle: Universal Information Limits and DIKWP Coefficients Technical Report. ResearchGate, 2025. https://www.researchgate.net/publication/399108508_From_Planck_Constant_to_Landauer%27s_Principle_Universal_Information_Limits_and_DIKWP_Coefficients_Technical_Report
4. Yucong Duan, DIKWP Semantic Mathematics Overview. ResearchGate, 2025. https://www.researchgate.net/publication/389324432_DIKWP_Semantic_Mathematics_Overview
5. Yucong Duan, Zhendong Guo, Shuaishuai Huang, DIKWP White-box Testing: Using Semantic Mathematics to Reduce the Hallucination Tendency of Large Models. ResearchGate, 2025. https://www.researchgate.net/publication/389068822_DIKWP_White-box_Testing_Using_Semantic_Mathematics_to_Reduce_the_Hallucination_Tendency_of_Large_Models
6. Yucong Duan, Shuaishuai Huang, Shiming Gong, DIKWP Channel Capacity Limitation and Genealogy Audit System Actual Construction and Delivery Report. ResearchGate, 2026. https://www.researchgate.net/publication/403964865_DIKWP_Channel_Capacity_Limitation_and_Genealogy_Audit_System_Actual_Construction_and_Delivery_Report
7. Yonggun Jun, Momčilo Gavrilov, John Bechhoefer, High-precision test of Landauer's principle in a feedback trap. Phys. Rev. Lett. 113, 190601, 2014. https://arxiv.org/abs/1408.5089
8. David Reeb, Michael M. Wolf, An improved Landauer Principle with finite-size corrections. New J. Phys. 16, 103011, 2014. https://arxiv.org/abs/1306.4352
